package ar.edu.unlam.pb2.test;

import static org.junit.Assert.*;

import org.junit.Test;

import ar.edu.unlam.pb2.domain.Anfibio;
import ar.edu.unlam.pb2.domain.FuerzaArmada;
import ar.edu.unlam.pb2.domain.Vehiculo;
import ar.edu.unlam.pb2.enumerators.TipoBatalla;
import ar.edu.unlam.pb2.domain.Hidroavion;
import ar.edu.unlam.pb2.domain.Tank;
import ar.edu.unlam.pb2.eva03.Avion;
import ar.edu.unlam.pb2.eva03.Volador;
import ar.edu.unlam.pb2.exceptions.ExistentBattleException;
import ar.edu.unlam.pb2.exceptions.ExistentVehicleException;
import ar.edu.unlam.pb2.exceptions.NonexistentBattleException;
import ar.edu.unlam.pb2.exceptions.NonexistentVehicleException;
import ar.edu.unlam.pb2.exceptions.NonvalidateToBattleException;

public class testArmyForces {

	/*
	 * @Test public void queSePuedaCrearUnObjetoVolador() { Vehiculo avion = new
	 * Volador(); Volador avion = new Avion(1, "A-10");
	 * 
	 * assertEquals(0.0, avion.getAltura()); assertEquals(0.0, avion.getAltura(),
	 * 0.01); }
	 */

	@Test
	public void queSePuedaCrearUnObjetoAnfibio() {
		Vehiculo anfibio = new Anfibio(1, "FROGGER-Z73", 125.0, 175);
		assertNotNull(anfibio);
	}

	@Test
	public void queSePuedaCrearUnObjetoHidroavion() {
		Vehiculo hidroavion = new Hidroavion(1, "Swrapper-T22", 600.0, 190);
		assertNotNull(hidroavion);
	}

	@Test
	public void queSePuedaArmarElConvoy() {
		FuerzaArmada canadianForces = new FuerzaArmada("Canadian Rangers");
		Integer key1 = 1;
		Integer key2 = 2;
		Integer key3 = 3;
		try {
			canadianForces.addVehicle(new Anfibio(1, "Froggy-z77", 125.0, 175), key1);
		} catch (Exception e) {
			e.getMessage();
		}
		try {
			canadianForces.addVehicle(new Hidroavion(2, "Z-risk 112", 600.0, 190), key2);
		} catch (Exception e) {
			e.getMessage();
		}
		try {
			canadianForces.addVehicle(new Tank(3, "Panzer-F52", 2000.0, 120), key3);
		} catch (Exception e) {
			e.getMessage();
		}
		Integer expectedValue = 3;
		Integer obtainedValue = canadianForces.getDefenseCapacity();
		assertEquals(expectedValue, obtainedValue);
	}

	@Test
	public void queSePuedaCrearUnaBatalla() {
		FuerzaArmada polandForces = new FuerzaArmada("The Land Forces");
		FuerzaArmada serbianForces = new FuerzaArmada("Serbian Forces");
		try {
			polandForces.createBattle("Stalingrad", TipoBatalla.TERRESTRE, 100.5, 20.3, 1);
		} catch (Exception e) {
			e.getMessage();
		}
		try {
			polandForces.createBattle("Kaliningrad", TipoBatalla.TERRESTRE, 150.5, 17.9, 2);
		} catch (Exception e) {
			e.getMessage();
		}
		Integer expectedValud = 2;
		Integer obtainedValue = polandForces.getBatallas().size();
	}

	@Test
	public void queSePuedaEnviarUnVehiculoALaBatalla() {
		FuerzaArmada polandForces = new FuerzaArmada("The Land Forces");
		try {
			polandForces.addVehicle(new Tank(1, "Reaper-223", 2500.0, 115), 1);
		} catch (Exception e) {
			e.getMessage();
		}

		try {
			polandForces.createBattle("Stalingrad", TipoBatalla.TERRESTRE, 100.5, 20.3, 1);
		} catch (ExistentBattleException e) {
			e.getMessage();
		}

		try {
			polandForces.sendVehicleToBattle(1, 1);
		} catch (Exception e) {
			e.getMessage();
		}
	}

	@Test
	public void queNoSePuedaEnviarUnHidroavionAUnaBatallaTerrestre() throws Exception {
		FuerzaArmada polandForces = new FuerzaArmada("The Land Forces");
		try {
			polandForces.addVehicle(new Hidroavion(1, "Zelda-117", 1800.0, 230), 1);
		} catch (ExistentVehicleException e) {
			e.getMessage();
		}

		try {
			polandForces.createBattle("Stalingrad", TipoBatalla.TERRESTRE, 100.5, 20.3, 1);
		} catch (ExistentBattleException e) {
			e.getMessage();
		}

		try {
			polandForces.sendVehicleToBattle(1, 1);
		} catch (Exception e) {
			e.getMessage();
		}
	}
}
