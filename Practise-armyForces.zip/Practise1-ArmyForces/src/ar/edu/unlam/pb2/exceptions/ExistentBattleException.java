package ar.edu.unlam.pb2.exceptions;

public class ExistentBattleException extends Exception {
	
	public ExistentBattleException (String message) {
		super(message);
	}
	
}
