package ar.edu.unlam.pb2.exceptions;

public class NonexistentBattleException extends Exception {
	
	public NonexistentBattleException (String message) {
		super(message);
	}
	
}
