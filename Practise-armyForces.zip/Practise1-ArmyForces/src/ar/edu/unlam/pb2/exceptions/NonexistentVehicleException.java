package ar.edu.unlam.pb2.exceptions;

public class NonexistentVehicleException extends Exception {
	
	public NonexistentVehicleException(String message) {
		super(message);
	}
	
}
