package ar.edu.unlam.pb2.exceptions;

public class ExistentVehicleException extends Exception {
	
	public ExistentVehicleException (String message) {
		super(message);
	}
	
}
