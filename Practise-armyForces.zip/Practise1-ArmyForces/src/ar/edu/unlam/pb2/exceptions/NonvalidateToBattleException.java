package ar.edu.unlam.pb2.exceptions;

public class NonvalidateToBattleException extends Exception {
	
	public NonvalidateToBattleException (String message) {
		super(message);
	}
	
}
