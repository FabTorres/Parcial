package ar.edu.unlam.pb2.enumerators;

public enum TipoBatalla {
	TERRESTRE, AEREA, ACUATICA
}
