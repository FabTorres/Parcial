package ar.edu.unlam.pb2.domain;

public abstract class Vehiculo {
	
	protected Integer codigo;
	protected String modelo;
	protected Double peso;
	protected Integer velocidadMax;
	
	public Vehiculo() {
	
	}

	public Vehiculo(Integer codigo, String modelo, Double peso, Integer velocidadMax) {
		this.codigo = codigo;
		this.modelo = modelo;
		this.peso = peso;
		this.velocidadMax = velocidadMax;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Double getPeso() {
		return peso;
	}

	public void setPeso(Double peso) {
		this.peso = peso;
	}

	public Integer getVelocidadMax() {
		return velocidadMax;
	}

	public void setVelocidadMax(Integer velocidadMax) {
		this.velocidadMax = velocidadMax;
	}
	
	public abstract String getTipo();
	
	
}
