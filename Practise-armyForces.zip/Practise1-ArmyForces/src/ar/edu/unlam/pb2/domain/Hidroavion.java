package ar.edu.unlam.pb2.domain;

import ar.edu.unlam.pb2.interfaces.Acuatico;
import ar.edu.unlam.pb2.interfaces.Aereo;

public class Hidroavion extends Vehiculo implements Aereo, Acuatico {

	public Hidroavion() {
	
	}

	public Hidroavion(Integer codigo, String modelo, Double peso, Integer velocidadMax) {
		super(codigo, modelo, peso, velocidadMax);
	
	}

	@Override
	public String getTipo() {
		return "Aereo";
	}

	@Override
	public void sumergir() {
		
	}

	@Override
	public void nadar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void volar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void planear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void aterrizar() {
		// TODO Auto-generated method stub
		
	}

}
