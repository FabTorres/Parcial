package ar.edu.unlam.pb2.domain;

import ar.edu.unlam.pb2.interfaces.Acuatico;
import ar.edu.unlam.pb2.interfaces.Terrestre;

public class Anfibio extends Vehiculo implements Acuatico, Terrestre {
	
	private Integer profundidad;
	
	public Anfibio() {
	
	}

	public Anfibio(Integer codigo, String modelo, Double peso, Integer velocidadMax) {
		super(codigo, modelo, peso, velocidadMax);
		this.profundidad = 0;
	}

	@Override
	public void sumergir() {
		
	}

	@Override
	public void nadar() {
		
	}

	public Integer getProfundidad() {
		return profundidad;
	}

	public void setProfundidad(Integer profundidad) {
		this.profundidad = profundidad;
	}

	@Override
	public String getTipo() {
		return "Terrestre/Acuatico";
	}

	

}
