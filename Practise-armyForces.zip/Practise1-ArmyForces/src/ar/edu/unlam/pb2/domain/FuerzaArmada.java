package ar.edu.unlam.pb2.domain;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import ar.edu.unlam.pb2.enumerators.TipoBatalla;
import ar.edu.unlam.pb2.exceptions.ExistentBattleException;
import ar.edu.unlam.pb2.exceptions.ExistentVehicleException;
import ar.edu.unlam.pb2.exceptions.NonexistentBattleException;
import ar.edu.unlam.pb2.exceptions.NonexistentVehicleException;
import ar.edu.unlam.pb2.exceptions.NonvalidateToBattleException;
import ar.edu.unlam.pb2.interfaces.Terrestre;

public class FuerzaArmada {

	private String nombre;
	private HashMap<Integer, Vehiculo> convoy;
	private TreeMap<Integer, Batalla> batallas;
	private TreeMap<Integer, Batalla> pruebita = new TreeMap<Integer, Batalla>();

	public FuerzaArmada() {

	}

	public FuerzaArmada(String nombre) {
		super();
		this.nombre = nombre;
		this.convoy = new HashMap<Integer, Vehiculo>();
		this.batallas = new TreeMap<Integer, Batalla>();
	}

	public void addVehicle(Vehiculo vehicle, Integer key) throws ExistentVehicleException {
		if (this.convoy.containsKey(key)) {
			throw new ExistentVehicleException("El vehiculo ya existe");
		}
		this.convoy.put(key, vehicle);
	}

	public Integer getDefenseCapacity() {
		return this.convoy.size();
	}

	public void createBattle(String nombre, TipoBatalla tipoBatalla, Double latitud, Double longitud, Integer key)
			throws ExistentBattleException {
		Batalla battle = new Batalla(nombre, tipoBatalla, latitud, longitud);
		String battleName = battle.getNombre().toLowerCase();

		if (this.batallas.containsKey(key)) {
			throw new ExistentBattleException("Ya existe la batalla");
		}
		this.batallas.put(key, battle);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public HashMap<Integer, Vehiculo> getConvoy() {
		return convoy;
	}

	public void setConvoy(HashMap<Integer, Vehiculo> convoy) {
		this.convoy = convoy;
	}

	public TreeMap<Integer, Batalla> getBatallas() {
		return this.batallas;
	}

	public void setBatallas(TreeMap<Integer, Batalla> batallas) {
		this.batallas = batallas;
	}

	private Boolean existVehicle(Integer key) throws NonexistentVehicleException {
		if (this.convoy.containsKey(key)) {
			return true;
		}
		throw new NonexistentVehicleException("The vehicle doesn't exists");
	}

	public void sendVehicleToBattle(Integer keyVehicle, Integer keyBattle)
			throws NonexistentVehicleException, NonexistentBattleException, NonvalidateToBattleException {
		Vehiculo vehicle = buscarVehiculo(keyVehicle);
		Batalla battle = buscarBatalla(keyBattle);
		if (isValidToBattle(battle, vehicle)) {
			battle.addVehicle(keyVehicle, vehicle);
		}
		throw new NonvalidateToBattleException("El vehiculo no es valido");
	}

	private Boolean isValidToBattle(Batalla battle, Vehiculo vehicle) throws NonvalidateToBattleException {
		if (vehicle.getTipo().toLowerCase().equals(battle.getTipoBatalla().toString().toLowerCase())) {
			return true;
		}
		throw new NonvalidateToBattleException("El vehiculo no es valido para la batalla");

	}

	private Batalla buscarBatalla(Integer keyBattle) throws NonexistentBattleException {
		for (Map.Entry<Integer, Batalla> entry : batallas.entrySet()) {
			if (entry.getKey().equals(keyBattle)) {
				Batalla battle = entry.getValue();
				return battle;
			}
		}
		throw new NonexistentBattleException("No se encontro la batalla");
	}

	private Vehiculo buscarVehiculo(Integer keyVehicle) throws NonexistentVehicleException {
		for (Map.Entry <Integer, Vehiculo> entry : convoy.entrySet()) {
			if (entry.getKey().equals(keyVehicle)) {
				Vehiculo vehicle = entry.getValue();
				return vehicle;
			}
		}
		throw new NonexistentVehicleException("No se encontro el vehiculo");

	}

}
