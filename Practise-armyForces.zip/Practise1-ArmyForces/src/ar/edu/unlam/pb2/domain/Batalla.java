package ar.edu.unlam.pb2.domain;

import java.util.HashMap;
import java.util.TreeMap;

import ar.edu.unlam.pb2.enumerators.TipoBatalla;

public class Batalla {
	
	private String nombre;
	private TipoBatalla tipoBatalla;
	private Double latitud;
	private Double longitud;
	private TreeMap <Integer, Vehiculo> vehiclesInBattle;
	
	public Batalla() {
		
	}

	public Batalla(String nombre, TipoBatalla tipoBatalla, Double latitud, Double longitud) {
		super();
		this.nombre = nombre.toLowerCase();
		this.tipoBatalla = tipoBatalla;
		this.latitud = latitud;
		this.longitud = longitud;
		this.vehiclesInBattle = new TreeMap<Integer, Vehiculo>();
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipoBatalla() {
		return tipoBatalla.toString().toLowerCase();
	}

	public void setTipoBatalla(TipoBatalla tipoBatalla) {
		this.tipoBatalla = tipoBatalla;
	}

	public Double getLatitud() {
		return latitud;
	}

	public void setLatitud(Double latitud) {
		this.latitud = latitud;
	}

	public Double getLongitud() {
		return longitud;
	}

	public void setLongitud(Double longitud) {
		this.longitud = longitud;
	}

	public TreeMap<Integer, Vehiculo> getVehiclesInBattle() {
		return vehiclesInBattle;
	}

	public void setVehiclesInBattle(TreeMap <Integer, Vehiculo> vehiclesInBattle) {
		this.vehiclesInBattle = vehiclesInBattle;
	}

	public void addVehicle(Integer key, Vehiculo vehicle) {
		this.vehiclesInBattle.put(key, vehicle);
	}

	

	
	
	
	
}
