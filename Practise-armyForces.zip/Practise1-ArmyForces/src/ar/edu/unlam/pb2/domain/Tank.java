package ar.edu.unlam.pb2.domain;

import ar.edu.unlam.pb2.interfaces.Terrestre;

public class Tank extends Vehiculo implements Terrestre{
	
	public Tank() {
		
	}

	public Tank(Integer codigo, String modelo, Double peso , Integer velMax) {
		super(codigo, modelo, peso, velMax);
	}

	@Override
	public String getTipo() {
		return "Terrestre";
	}	
	
	
}
