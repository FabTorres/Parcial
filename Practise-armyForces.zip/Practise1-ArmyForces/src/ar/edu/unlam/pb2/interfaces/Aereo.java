package ar.edu.unlam.pb2.interfaces;

public interface Aereo {
	
	public abstract void volar();
	
	public abstract void planear();
	
	public abstract void aterrizar();
	
}
