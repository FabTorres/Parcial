package ar.edu.unlam.pb2.interfaces;

public interface Acuatico {
	
	public abstract void sumergir();
	
	public abstract void nadar();

	
}
