package ar.edu.unlam.pb2.interfaces;

public interface Terrestre {

	
}
